// div.h
float div(int a,int b);
