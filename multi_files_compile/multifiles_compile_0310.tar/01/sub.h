// sub.h
int sub(int a,int b);
