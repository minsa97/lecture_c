// div.c
float div(int a, int b){
    return (float)a/(float)b;
}
