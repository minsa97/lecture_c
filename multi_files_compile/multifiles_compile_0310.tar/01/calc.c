// calc.c
#include <stdio.h>
#include "sum.h"

int main(void){
    int res;
    res=sum(1,2);
    printf("합: %d\n", res);

    return 0;
}
