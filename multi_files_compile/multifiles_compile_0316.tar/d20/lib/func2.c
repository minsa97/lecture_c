// func2.c
#include <stdio.h>
#include "func1.h"
#include "func2.h"

void foo2(void){
    printf("func2.c - foo2()\n");
}
