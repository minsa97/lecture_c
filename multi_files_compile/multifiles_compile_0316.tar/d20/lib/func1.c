// func1.c
#include <stdio.h>
#include "func1.h"
#include "func2.h"

void foo1(void){
    printf("func1.c - foo1()\n");
}
