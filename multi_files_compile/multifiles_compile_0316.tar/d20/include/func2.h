// func2.h
#ifndef FUNC2_H
#define FUNC2_H
void foo2();
#endif
