// func1.h
#ifndef FUNC1_H
#define FUNC1_H
void foo1();
#endif
