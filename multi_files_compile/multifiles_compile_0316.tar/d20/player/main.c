// main.c
#include <stdio.h>
#include "func1.h"
#include "func2.h"

int main(void){
    foo1();
    foo2();

    return 0;
}
