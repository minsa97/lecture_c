// memo.c
#include "diary.h"
void memo(void){
    printf("memo() function!\n");
}
