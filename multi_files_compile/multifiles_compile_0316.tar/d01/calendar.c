// calendar.c
#include "diary.h"
void calendar(void){
    printf("calendar() function!\n");
}
