// function.c
#include "function.h"

void function(){
    printf("function()\n");
}
