// main.c

#include <stdio.h>
#include "function.h"

int main(){
    printf("main()\n");
    function();

    return 0;
}