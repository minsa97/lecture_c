// libtest.h
#include <stdio.h>
void libtest(void);