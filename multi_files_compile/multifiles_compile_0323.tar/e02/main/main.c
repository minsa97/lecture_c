// main.c

#include <stdio.h>
#include "function.h"
#include "../common/libtest.h"

int main(void){
    printf("main()\n");
    function();
    libtest();

    return 0;
}
