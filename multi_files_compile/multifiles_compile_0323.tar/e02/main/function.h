// function.h
#include <stdio.h>
void function(void);
