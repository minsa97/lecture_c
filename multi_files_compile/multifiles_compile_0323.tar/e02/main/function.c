// function.c
#include "function.h"
void function(void){
    printf("function()\n");
}
