// libtest.c
#include "../common/libtest.h"
void libtest(void){
    printf("libtest()\n");
}